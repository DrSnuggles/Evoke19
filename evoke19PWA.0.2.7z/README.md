# evoke 2019 Results demo

Includes:
- ANSI / ASCII PC
- ANSI / ASCII Amiga
- Freestyle Gfx
- Pixel Gfx
- party song
- original libertine track
- tracked libertine remixes
- streamed music (online version)

Since there is no Renoise js playback routine available i decided to use an export (MP3/48kHz/320kbps) which is of course available in the offline version.

BMP was converted to PNG.

## Idea

Show grafix while playing audio :)

Learn or do somthing new (at least for me: PWA(on-/offline detection and local data storage) )

Reuse something old (lds.js + jsgoniometer)

~~Use friends work (webMPT with generic audio processor with Jürgen Wothke)~~
Use friends work (OpenMPT (libopenmpt+chiptune2) by Saga Musix)

Ammigaaaaaaaaaaaaaaaaa (style)

## evoke 2019 Infos

### Tracked music rulez
Competition: Tracked Music - “Libertine” Remix

This year, we decided to honour another PC demoscene classic:
“Libertine”, the soundtrack from Cascada’s “Hex Appeal” (1993).
Minimalistic sample usage and a catchy melody make it a particularly thankful remix candidate.The compo is endorsed by the original composer, Zodiak/Cascada.

The original song (libertine.mod) is available for download at Modland. Please keep in mind that despite the .mod file extension, this is a 6-channel Fast Tracker 2 module.
* Supported formats: XM IT S3M MOD RNS XRNS
* You are only allowed to use the original samples, no additional samples are allowed. You are not allowed to duplicate, cut or modify a sample via your tracker’s sample editor, apart from setting, moving or removing a loop. All other sample modifications have to be done via tracker commands. The original order of samples in the sample list has to remain intact.
* Some of the original melodies should be recognisable at least somewhere in you remix.
* Usage of VST plugins is NOT allowed.
* If you use Renoise, you are NOT allowed to use the internal effect and instrument devices. Also, you are allowed to use only one effect column at a time.
* Maximum playing time: 3:30, longer songs will be faded out from 3:30 to 3:40.
* Playback with current versions of OpenMPT (XM, S3M, IT), 8bitbubsy’s ProTracker (MOD), or Renoise (RNS, XRNS).
